#include "hotel.h"
#include "ui_hotel.h"
#include "addcustomerform.h"
#include "viewcustomersform.h"
#include "addnewroom.h"
#include "viewrooms.h"
#include "makereserve.h"
#include "viewrev.h"
#include "cancelrev.h"

std::vector<Customer> customer_list;
std::vector<rooms> room_list;
std::vector<reserve> reservation_list;

Hotel::Hotel(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Hotel) {
    ui->setupUi(this);
}

Hotel::~Hotel() {
    delete ui;
}

void Hotel::on_addCustomerButton_clicked(){
    AddCustomerForm *addCustomerForm = new class AddCustomerForm(this);
    addCustomerForm->exec();
}

void Hotel::on_viewCustomersButton_clicked(){
    ViewCustomersForm *viewCustomersForm = new class ViewCustomersForm(this);
    viewCustomersForm->exec();
}


void Hotel::on_AddNewRoomButton_clicked(){
    AddNewRoom *AddNewRoom = new  class AddNewRoom(this);
    AddNewRoom->exec();

}


void Hotel::on_ViewRooms_clicked(){
    ViewRooms *ViewRooms = new class ViewRooms;
    ViewRooms->exec();
}

void Hotel::on_MakeRev_clicked(){
    makereserve *makereserve = new class makereserve;
    makereserve->exec();


}


void Hotel::on_ViewRev_clicked()
{
    viewrev *viewrev = new class viewrev;
    viewrev->exec();
}


void Hotel::on_CancelRev_clicked(){
    CancelRev *CancelRev = new class CancelRev;
    CancelRev->exec();

}

