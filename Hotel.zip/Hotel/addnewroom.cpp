#include "addnewroom.h"
#include "ui_addnewroom.h"
#include <QMessageBox>

AddNewRoom::AddNewRoom(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AddNewRoom)
{
    ui->setupUi(this);
}

AddNewRoom::~AddNewRoom()
{
    delete ui;
}






void AddNewRoom::on_saveroom_clicked()
{
    rooms Room;
    Room.id = room_list.size() + 1;
    Room.Capacity = ui->Capacity->text().toInt();
    Room.day_price = ui->Price->text().toInt();
    Room.Description = ui->Description->text().toStdString();

    if(ui->Capacity->text().isEmpty() or ui->Price->text().isEmpty()){
        QMessageBox::warning(this, "Error", "All fields must be filled!");
        return;
    }

    room_list.push_back(Room);

    QMessageBox::information(this, "Success", "Room saved successfully!");

    this->close();
}

